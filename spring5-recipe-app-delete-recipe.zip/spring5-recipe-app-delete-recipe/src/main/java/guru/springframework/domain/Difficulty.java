package guru.springframework.domain;

/**
 * Created by jt on 6/13/17.
 */
public enum Difficulty {

    EASY, MODERATE, KIND_OF_HARD, HARD
}
